package service

// GreetService 负责处理关于问候的业务逻辑，该服务的方法会被暴露给前端调用。
type GreetService struct{}

// NewGreetService 是服务的构造函数，方便将来引入依赖注入。
func NewGreetService() *GreetService {
	return &GreetService{}
}

// Greet 返回一条带有指定名称的问候消息。
func (g *GreetService) Greet(name string) string {
	return "Hello " + name + "!"
}
