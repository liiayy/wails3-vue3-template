<script setup lang="ts">
import { ref, onMounted, onUnmounted } from 'vue'
// @ts-ignore - Wails 3 generated bindings typings might not be fully supported yet or require tsc tweaks
import { GreetService } from '../../bindings/myapp2/internal/service'
import { Events } from '@wailsio/runtime'

const name = ref('')
const resultText = ref("Please enter your name below 👇")
const currentTime = ref("")

// 订阅后端事件
onMounted(() => {
  Events.On('time', (time: unknown) => {
    currentTime.value = time as string
  })
})

onUnmounted(() => {
  Events.Off('time')
})

function onGreet() {
  if (name.value.trim() === '') {
    resultText.value = 'Please enter a name first.'
    return
  }
  GreetService.Greet(name.value).then((result: string) => {
    resultText.value = result
  }).catch((err: unknown) => {
    resultText.value = "Error: " + String(err)
  })
}
</script>

<template>
  <t-card :bordered="false" class="shadow-sm rounded-lg">
    <div class="space-y-6 flex flex-col items-center py-10">
      
      <div class="text-center space-y-2">
        <h2 class="text-2xl font-bold text-[var(--td-text-color-primary)]">
          Welcome to Wails 3 Project
        </h2>
        <p class="text-[var(--td-text-color-secondary)]">
          Built with Vue 3 + Vite + Tailwind CSS + TDesign + Go
        </p>
      </div>

      <div class="flex flex-col items-center gap-4 w-full max-w-sm">
        <div class="h-10 text-lg font-medium text-[var(--td-brand-color)]">
          {{ resultText }}
        </div>
        
        <t-input 
          v-model="name"
          placeholder="Enter your name..." 
          @enter="onGreet"
          size="large"
          class="w-full text-center"
        />

        <t-button theme="primary" size="large" @click="onGreet" class="w-full">
          Greet Interface
        </t-button>
      </div>

      <t-alert theme="info" class="mt-8">
        <template #title>Current Time from Backend:</template>
        {{ currentTime || "Waiting for 'time' event..." }}
      </t-alert>
      
    </div>
  </t-card>
</template>
